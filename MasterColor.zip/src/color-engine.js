/**
 * ColorEngine.js — Motor de Análise de Cor Profissional
 * ClipPaste AI — by Alex Ascencio
 *
 * Analisa imagens de referência e calcula parâmetros Lumetri Color
 * precisos para replicação de look cinematográfico.
 *
 * Pipeline:
 *  1. Amostragem de pixels (grid uniforme)
 *  2. Separação em zonas tonais (sombras / meios-tons / altas luzes)
 *  3. Conversão para espaços de cor perceptuais (XYZ → LAB)
 *  4. Análise de temperatura de cor (McCamy + McCann)
 *  5. Análise de histograma e range dinâmico
 *  6. Mapeamento para parâmetros Lumetri Color
 *  7. Validação anti-clipping (highlights protegidos)
 */

'use strict';

/* ═══════════════════════════════════════════════════════════════════════
   CONSTANTES
   ═══════════════════════════════════════════════════════════════════════ */

const D65 = { x: 0.95047, y: 1.0, z: 1.08883 }; // Iluminante D65

// Lumetri Color — limites de segurança (sem clipar highlights)
const LUMETRI_LIMITS = {
  exposure:    { min: -3.5,  max: 3.5  },
  contrast:    { min: -60,   max: 60   },
  highlights:  { min: -90,   max: 30   },
  shadows:     { min: -60,   max: 80   },
  whites:      { min: -60,   max: 40   },
  blacks:      { min: -60,   max: 50   },
  temperature: { min: -55,   max: 55   },
  tint:        { min: -35,   max: 35   },
  saturation:  { min: 60,    max: 155  },
  vibrance:    { min: -40,   max: 50   }
};

/* ═══════════════════════════════════════════════════════════════════════
   CONVERSÕES DE COR
   ═══════════════════════════════════════════════════════════════════════ */

/**
 * Lineariza valor sRGB (remove gamma)
 */
function linearize(v) {
  const n = v / 255;
  return n <= 0.04045 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
}

/**
 * RGB (0-255) → XYZ (D65)
 */
function rgbToXyz(r, g, b) {
  const rl = linearize(r);
  const gl = linearize(g);
  const bl = linearize(b);
  return {
    x: rl * 0.4124564 + gl * 0.3575761 + bl * 0.1804375,
    y: rl * 0.2126729 + gl * 0.7151522 + bl * 0.0721750,
    z: rl * 0.0193339 + gl * 0.1191920 + bl * 0.9503041
  };
}

/**
 * XYZ → CIE L*a*b*
 */
function xyzToLab(xyz) {
  function f(t) {
    const delta = 6 / 29;
    return t > delta * delta * delta
      ? Math.cbrt(t)
      : t / (3 * delta * delta) + 4 / 29;
  }
  const fx = f(xyz.x / D65.x);
  const fy = f(xyz.y / D65.y);
  const fz = f(xyz.z / D65.z);
  return {
    L: 116 * fy - 16,
    a: 500 * (fx - fy),
    b: 200 * (fy - fz)
  };
}

/**
 * RGB → HSL
 */
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return { h: h * 360, s, l };
}

/**
 * Estima temperatura de cor em Kelvin a partir de valores RGB médios
 * Baseado na aproximação de Hernandez-Andres (2001) adaptada
 */
function estimateColorTemp(avgR, avgG, avgB) {
  if (avgR < 1 || avgB < 1) return 6500;
  // Razão R/B como proxy de temperatura
  const rb = avgR / avgB;
  // Mapeamento empírico calibrado contra amostras de cena
  // rb ≈ 0.6  → 10000K (azul frio)
  // rb ≈ 1.0  → 6500K  (neutro D65)
  // rb ≈ 1.8  → 3200K  (tungstênio quente)
  const kelvin = 6500 / Math.pow(rb, 1.65);
  return Math.max(1500, Math.min(12000, kelvin));
}

/* ═══════════════════════════════════════════════════════════════════════
   ANÁLISE DA IMAGEM DE REFERÊNCIA
   ═══════════════════════════════════════════════════════════════════════ */

/**
 * Analisa ImageData e retorna um ColorProfile completo
 * @param {ImageData} imageData
 * @returns {ColorProfile}
 */
function analyzeImage(imageData) {
  const pixels = imageData.data;
  const totalPx = pixels.length / 4;

  // Amostragem: máximo 4000 pixels uniformemente distribuídos
  const step = Math.max(1, Math.floor(totalPx / 4000));

  // Acumuladores por zona tonal
  const zone = {
    shadow:    { r: 0, g: 0, b: 0, n: 0 }, // L* < 30
    midtone:   { r: 0, g: 0, b: 0, n: 0 }, // 30 ≤ L* < 75
    highlight: { r: 0, g: 0, b: 0, n: 0 }  // L* ≥ 75
  };

  // Globais
  let rSum = 0, gSum = 0, bSum = 0;
  let labLSum = 0, satSum = 0;
  let clippedHigh = 0, clippedLow = 0;
  const lumHist = new Uint32Array(256);
  let samples = 0;

  for (let i = 0; i < pixels.length; i += 4 * step) {
    const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];

    // Luminância relativa (Rec. 709)
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    lumHist[Math.round(lum)]++;

    // LAB para zona tonal perceptual
    const xyz = rgbToXyz(r, g, b);
    const lab = xyzToLab(xyz);
    labLSum += lab.L;

    // Separação de zona
    let z;
    if (lab.L < 30) { z = zone.shadow; clippedLow += lab.L < 3 ? 1 : 0; }
    else if (lab.L < 75) { z = zone.midtone; }
    else { z = zone.highlight; clippedHigh += lab.L > 97 ? 1 : 0; }

    z.r += r; z.g += g; z.b += b; z.n++;

    // Saturação HSL
    const hsl = rgbToHsl(r, g, b);
    satSum += hsl.s;

    rSum += r; gSum += g; bSum += b;
    samples++;
  }

  // Médias globais
  const avgR = rSum / samples;
  const avgG = gSum / samples;
  const avgB = bSum / samples;
  const avgLabL = labLSum / samples;
  const avgSat = satSum / samples;

  // Médias por zona (com fallback para global se zona vazia)
  function zoneAvg(z) {
    if (z.n === 0) return { r: avgR, g: avgG, b: avgB };
    return { r: z.r / z.n, g: z.g / z.n, b: z.b / z.n };
  }

  const sh = zoneAvg(zone.shadow);
  const mt = zoneAvg(zone.midtone);
  const hl = zoneAvg(zone.highlight);

  // Luminâncias por zona
  const lumSh = 0.2126 * sh.r + 0.7152 * sh.g + 0.0722 * sh.b;
  const lumMt = 0.2126 * mt.r + 0.7152 * mt.g + 0.0722 * mt.b;
  const lumHl = 0.2126 * hl.r + 0.7152 * hl.g + 0.0722 * hl.b;

  // Distribuição de luminância (percentis)
  let cumSum = 0;
  const p05idx = samples * 0.05, p50idx = samples * 0.5, p95idx = samples * 0.95;
  let p05 = 0, p50 = 128, p95 = 230;
  let cumPrev = 0;
  for (let i = 0; i < 256; i++) {
    cumSum += lumHist[i];
    if (cumPrev < p05idx && cumSum >= p05idx) p05 = i;
    if (cumPrev < p50idx && cumSum >= p50idx) p50 = i;
    if (cumPrev < p95idx && cumSum >= p95idx) p95 = i;
    cumPrev = cumSum;
  }

  const colorTemp = estimateColorTemp(avgR, avgG, avgB);

  // Bias de tint: canal verde relativo a R+B
  const tintBias = avgG - (avgR + avgB) / 2;

  // Razão de contraste entre highlight e shadow médias
  const contrastRatio = lumHl / (lumSh + 1);

  // Proteção: percentual de pixels clipados
  const overexposed  = clippedHigh / samples;
  const underexposed = clippedLow  / samples;

  return {
    // Globais
    avgR, avgG, avgB,
    avgLabL,   // luminância perceptual L* média (0-100)
    avgSat,    // saturação média (0-1)
    colorTemp, // Kelvin estimado
    tintBias,  // bias de verde (-50..+50)

    // Zonas
    shadows:    sh,
    midtones:   mt,
    highlights: hl,
    lumShadow:  lumSh,
    lumMid:     lumMt,
    lumHighlight: lumHl,

    // Histograma e distribuição
    lumHist,
    p05, p50, p95, // percentis de luminância

    // Qualidade e proteção
    contrastRatio,
    overexposed,   // 0-1, fração de pixels clipados no branco
    underexposed,  // 0-1, fração de pixels clipados no preto
    dynamicRange: p95 - p05, // alcance dinâmico em valores 0-255
    samples
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   MAPEAMENTO PARA LUMETRI COLOR
   ═══════════════════════════════════════════════════════════════════════ */

/**
 * Calcula o viés de cor de uma zona (quanto se desvia do cinza neutro)
 * Retorna vetor normalizado {r, g, b} onde 0 = neutro
 */
function colorBias(zone) {
  const avg = (zone.r + zone.g + zone.b) / 3;
  if (avg < 2) return { r: 0, g: 0, b: 0 };
  const dr = (zone.r - avg) / avg;
  const dg = (zone.g - avg) / avg;
  const db = (zone.b - avg) / avg;
  // Limitar a ±0.3 para evitar correções agressivas
  const clamp = v => Math.max(-0.3, Math.min(0.3, v));
  return { r: clamp(dr), g: clamp(dg), b: clamp(db) };
}

/**
 * Clamp seguro para valores Lumetri
 */
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

/**
 * Converte ColorProfile em parâmetros prontos para aplicar no Lumetri Color
 * @param {Object} profile — resultado de analyzeImage()
 * @returns {LumetriParams}
 */
function toLumetriParams(profile) {
  const P = profile;

  /* ── BASIC CORRECTION ──────────────────────────────────────────────── */

  // EXPOSURE: ajuste para alinhar luminância perceptual
  // L*=50 → exposição neutra; cada ~20 L* ≈ 1 stop
  const rawExposure = (P.avgLabL - 50) / 20;
  const exposure = clamp(-rawExposure, LUMETRI_LIMITS.exposure.min, LUMETRI_LIMITS.exposure.max);

  // CONTRAST: baseado no alcance dinâmico da cena de referência
  // dynamicRange 200 → contraste 0; dynamicRange 100 → contraste -30; 230 → +40
  const contrast = clamp((P.dynamicRange - 180) * 0.4, LUMETRI_LIMITS.contrast.min, LUMETRI_LIMITS.contrast.max);

  // HIGHLIGHTS: proteger altas luzes se estiverem acima do ideal
  // Ideal: p95 ≈ 230. Se maior, puxar para baixo.
  const rawHL = (P.p95 - 230) * -0.8;
  const highlights = clamp(rawHL, LUMETRI_LIMITS.highlights.min, LUMETRI_LIMITS.highlights.max);

  // SHADOWS: levantar ou baixar sombras
  // Ideal: p05 ≈ 20. Se menor (preto esmagado), levantar. Se maior (cinza), abaixar.
  const rawSH = (P.p05 - 20) * 1.2;
  const shadows = clamp(rawSH, LUMETRI_LIMITS.shadows.min, LUMETRI_LIMITS.shadows.max);

  // WHITES: ponto branco fino
  const whites = clamp((P.lumHighlight - 220) * -0.5, LUMETRI_LIMITS.whites.min, LUMETRI_LIMITS.whites.max);

  // BLACKS: ponto preto fino
  const blacks = clamp((P.lumShadow - 15) * 0.8, LUMETRI_LIMITS.blacks.min, LUMETRI_LIMITS.blacks.max);

  // TEMPERATURE: distância de 6500K → slider Premiere
  // Premiere: -100 = muito frio (~2000K), +100 = muito quente (~10000K)
  // Mapeamento linear na faixa ±2500K em torno de 6500K
  const rawTemp = (P.colorTemp - 6500) / 40;
  const temperature = clamp(rawTemp, LUMETRI_LIMITS.temperature.min, LUMETRI_LIMITS.temperature.max);

  // TINT: correção de verde
  // tintBias positivo → verde excessivo → tint negativo (magenta)
  const tint = clamp(P.tintBias * -0.5, LUMETRI_LIMITS.tint.min, LUMETRI_LIMITS.tint.max);

  // SATURATION
  // avgSat 0.4 → 100%; 0.2 → 80%; 0.7 → 135%
  const saturation = clamp(100 + (P.avgSat - 0.4) * 140, LUMETRI_LIMITS.saturation.min, LUMETRI_LIMITS.saturation.max);

  // VIBRANCE: boost nas cores menos saturadas
  const vibrance = clamp((P.avgSat - 0.35) * 80, LUMETRI_LIMITS.vibrance.min, LUMETRI_LIMITS.vibrance.max);

  /* ── COLOR WHEELS ──────────────────────────────────────────────────── */

  const shadowBias = colorBias(P.shadows);
  const midBias    = colorBias(P.midtones);
  const hlBias     = colorBias(P.highlights);

  // Intensidade do color wheel: magnitude do viés × escala para Premiere
  // Premiere color wheels aceitam valores pequenos (-1 a +1 interno)
  const WHEEL_SCALE = 0.18; // escala conservadora para look profissional

  function wheelVal(bias) {
    return {
      r: bias.r * WHEEL_SCALE,
      g: bias.g * WHEEL_SCALE,
      b: bias.b * WHEEL_SCALE
    };
  }

  /* ── PROTEÇÃO ANTI-CLIP ──────────────────────────────────────────── */
  // Se há mais de 2% de pixels clipados, reduzir agressividade
  const clipProtection = P.overexposed > 0.02 ? 0.7 : 1.0;

  return {
    basic: {
      exposure:    parseFloat((exposure * clipProtection).toFixed(3)),
      contrast:    Math.round(contrast),
      highlights:  Math.round(highlights),
      shadows:     Math.round(shadows),
      whites:      Math.round(whites),
      blacks:      Math.round(blacks),
      temperature: parseFloat(temperature.toFixed(1)),
      tint:        parseFloat(tint.toFixed(1)),
      saturation:  parseFloat(saturation.toFixed(1)),
      vibrance:    parseFloat(vibrance.toFixed(1))
    },
    colorWheels: {
      shadows:    wheelVal(shadowBias),
      midtones:   wheelVal(midBias),
      highlights: wheelVal(hlBias)
    },
    // Metadados da análise para display na UI
    meta: {
      colorTemp:    Math.round(P.colorTemp),
      avgLabL:      parseFloat(P.avgLabL.toFixed(1)),
      dynamicRange: P.dynamicRange,
      overexposed:  parseFloat((P.overexposed * 100).toFixed(1)),
      underexposed: parseFloat((P.underexposed * 100).toFixed(1)),
      saturation:   parseFloat((P.avgSat * 100).toFixed(1)),
      dominant:     detectDominantLook(P)
    }
  };
}

/**
 * Detecta o "look" dominante da referência (string para UI)
 */
function detectDominantLook(P) {
  if (P.avgLabL > 65)    return 'High Key';
  if (P.avgLabL < 35)    return 'Low Key';
  if (P.colorTemp < 4000) return 'Tungstênio';
  if (P.colorTemp > 8000) return 'Azul Frio';
  if (P.contrastRatio > 8) return 'Alto Contraste';
  if (P.dynamicRange < 100) return 'Low Contrast / Flat';
  if (P.avgSat > 0.55)   return 'Saturado';
  if (P.avgSat < 0.2)    return 'Dessaturado';
  return 'Balanced';
}

/* ═══════════════════════════════════════════════════════════════════════
   API PÚBLICA
   ═══════════════════════════════════════════════════════════════════════ */

const ColorEngine = {
  /**
   * Analisa uma imagem e retorna parâmetros Lumetri prontos para uso.
   * @param {HTMLCanvasElement} canvas — canvas com a imagem desenhada
   * @param {number} [maxSize=256]    — resolução máxima para análise (performance)
   * @returns {{ profile: ColorProfile, params: LumetriParams }}
   */
  analyze(canvas, maxSize = 256) {
    // Criar canvas de análise redimensionado para performance
    const offscreen = document.createElement('canvas');
    const scale = Math.min(1, maxSize / Math.max(canvas.width, canvas.height));
    offscreen.width  = Math.round(canvas.width  * scale);
    offscreen.height = Math.round(canvas.height * scale);

    const ctx = offscreen.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(canvas, 0, 0, offscreen.width, offscreen.height);

    const imageData = ctx.getImageData(0, 0, offscreen.width, offscreen.height);
    const profile   = analyzeImage(imageData);
    const params    = toLumetriParams(profile);

    return { profile, params };
  },

  /**
   * Carrega uma File/Blob de imagem em um canvas e analisa.
   * @param {File|Blob} file
   * @returns {Promise<{ profile, params, dataUrl }>}
   */
  analyzeFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width  = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0);
          const result = ColorEngine.analyze(canvas);
          resolve({ ...result, dataUrl: e.target.result });
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
};

// Exportar para uso no painel CEP
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ColorEngine;
} else {
  window.ColorEngine = ColorEngine;
}
