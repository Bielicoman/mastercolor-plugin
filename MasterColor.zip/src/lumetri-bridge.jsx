/**
 * lumetri-bridge.jsx — ExtendScript Host
 * ClipPaste AI — by Alex Ascencio
 *
 * Responsável por:
 * 1. Acessar sequência e clips selecionados no Premiere
 * 2. Criar camada de ajuste acima dos clips selecionados
 * 3. Aplicar Lumetri Color com parâmetros calculados pelo ColorEngine
 * 4. Retornar resultado ao painel
 *
 * IMPORTANTE: ExtendScript clássico — sem let/const/arrow functions
 * ─── Compatibilidade: Premiere Pro 2022 – 2026+ ───────────────────
 */

// ─── Utilitários ExtendScript ────────────────────────────────────────

function log(msg) {
  $.writeln("[ClipPaste] " + msg);
}

function safeJSON(val) {
  try { return JSON.stringify(val); }
  catch(e) { return '{"error":"serialize"}'; }
}

// ─── API principal exposta ao painel ────────────────────────────────

/**
 * Retorna informações da sequência ativa e clips selecionados
 */
function getSelectedClipsInfo() {
  try {
    if (!app.project) return safeJSON({ error: "Nenhum projeto aberto" });
    var seq = app.project.activeSequence;
    if (!seq) return safeJSON({ error: "Nenhuma sequência ativa" });

    var selected = [];
    var tracks = seq.videoTracks;

    for (var ti = 0; ti < tracks.numTracks; ti++) {
      var track = tracks[ti];
      for (var ci = 0; ci < track.clips.numItems; ci++) {
        var clip = track.clips[ci];
        if (clip.isSelected()) {
          selected.push({
            trackIndex: ti,
            clipIndex: ci,
            name: clip.name,
            start: clip.start.seconds,
            end: clip.end.seconds
          });
        }
      }
    }

    return safeJSON({
      ok: true,
      sequence: seq.name,
      selected: selected,
      count: selected.length
    });
  } catch(e) {
    return safeJSON({ error: e.message });
  }
}

/**
 * Cria uma camada de ajuste na sequência ativa
 * posicionada acima dos clips selecionados e aplica Lumetri Color.
 *
 * @param {string} paramsJson — JSON serializado com { basic, colorWheels }
 */
function applyColorGrade(paramsJson) {
  try {
    var params = JSON.parse(paramsJson);
    var seq = app.project.activeSequence;
    if (!seq) return safeJSON({ error: "Nenhuma sequência ativa" });

    var tracks = seq.videoTracks;

    // 1. Encontrar clips selecionados e calcular range de tempo
    var selectedClips = [];
    var minStart = Infinity, maxEnd = -Infinity;
    var maxTrackIdx = -1;

    for (var ti = 0; ti < tracks.numTracks; ti++) {
      var track = tracks[ti];
      for (var ci = 0; ci < track.clips.numItems; ci++) {
        var clip = track.clips[ci];
        if (clip.isSelected()) {
          var startSec = clip.start.seconds;
          var endSec   = clip.end.seconds;
          if (startSec < minStart) minStart = startSec;
          if (endSec   > maxEnd)   maxEnd   = endSec;
          if (ti > maxTrackIdx)    maxTrackIdx = ti;
          selectedClips.push({ track: ti, clip: ci, clipObj: clip });
        }
      }
    }

    if (selectedClips.length === 0) {
      return safeJSON({ error: "Nenhum clip selecionado na timeline" });
    }

    // 2. Criar camada de ajuste acima da faixa mais alta
    var adjTrackIdx = maxTrackIdx + 1;

    // Garantir que a faixa existe (Premiere adiciona automaticamente se necessário)
    while (tracks.numTracks <= adjTrackIdx) {
      seq.videoTracks.addTrack();
    }

    var adjTrack = tracks[adjTrackIdx];

    // 3. Criar ProjectItem de camada de ajuste
    // O Premiere não tem API direta para adjustment layers via script,
    // então usamos addVideoClip com um item de cor sólida transparente.
    // A solução mais robusta: usar clip existente selecionado e aplicar Lumetri nele diretamente.
    // Strategy: aplica Lumetri em cada clip selecionado individualmente.

    var results = [];
    for (var si = 0; si < selectedClips.length; si++) {
      var info = selectedClips[si];
      var clipObj = info.clipObj;
      var result = applyLumetriToClip(clipObj, params, si);
      results.push(result);
    }

    // Tentar criar adjustment layer se possível (Premiere 2022+)
    var adjLayerResult = tryCreateAdjustmentLayer(seq, adjTrackIdx, minStart, maxEnd, params);

    return safeJSON({
      ok: true,
      strategy: adjLayerResult.ok ? "adjustment_layer" : "direct",
      clipsModified: results.length,
      adjLayer: adjLayerResult,
      results: results
    });

  } catch(e) {
    log("Erro applyColorGrade: " + e.message + " line " + e.line);
    return safeJSON({ error: e.message, line: e.line });
  }
}

/**
 * Aplica efeito Lumetri Color diretamente em um clip
 */
function applyLumetriToClip(clipObj, params, idx) {
  try {
    var clipName = clipObj.name;

    // Verificar/adicionar Lumetri Color ao clip
    var components = clipObj.components;
    var lumetri = null;

    // Procurar Lumetri existente
    for (var i = 0; i < components.numItems; i++) {
      var comp = components[i];
      if (comp.displayName.indexOf("Lumetri") >= 0) {
        lumetri = comp;
        break;
      }
    }

    // Adicionar Lumetri se não existir
    if (!lumetri) {
      // Tentar via QE DOM para adicionar efeito
      var qeSeq = qe.project.getActiveSequence();
      if (qeSeq) {
        var qeTrack = qeSeq.getVideoTrackAt(idx);
        // QE DOM: addEffect via nome
        // Nota: o nome do efeito pode variar por idioma da instalação
        // Usamos o matchName (interno) para robustez
        try {
          clipObj.addVideoEffect(qe.project.getVideoEffectByMatchName("lumetri"));
        } catch(ex) {
          log("addVideoEffect via matchName falhou: " + ex.message);
        }

        // Tentar pelo nome display
        try {
          var effectName = "Lumetri Color";
          clipObj.addVideoEffect(qe.project.getVideoEffectByName(effectName));
        } catch(ex2) {
          log("addVideoEffect via display name falhou: " + ex2.message);
        }
      }

      // Re-procurar após adição
      for (var j = 0; j < components.numItems; j++) {
        if (components[j].displayName.indexOf("Lumetri") >= 0) {
          lumetri = components[j];
          break;
        }
      }
    }

    if (!lumetri) {
      return { clip: clipName, ok: false, error: "Não foi possível adicionar Lumetri Color" };
    }

    // Aplicar parâmetros básicos
    var basic = params.basic;
    var props = lumetri.properties;

    // Mapeamento de nomes de propriedade Lumetri
    // Os nomes podem variar por versão — tentamos os mais comuns
    var propMap = {
      exposure:    ["Exposure",    "Exposição"],
      contrast:    ["Contrast",    "Contraste"],
      highlights:  ["Highlights",  "Realces"],
      shadows:     ["Shadows",     "Sombras"],
      whites:      ["Whites",      "Brancos"],
      blacks:      ["Blacks",      "Pretos"],
      temperature: ["Temperature", "Temperatura"],
      tint:        ["Tint",        "Matiz"],
      saturation:  ["Saturation",  "Saturação"],
      vibrance:    ["Vibrance",    "Vibração"]
    };

    var applied = [];
    for (var param in propMap) {
      var names = propMap[param];
      var val = basic[param];
      if (val === undefined) continue;

      for (var n = 0; n < names.length; n++) {
        try {
          var prop = props.getNamedProperty(names[n]);
          if (prop) {
            prop.setValue(val, true);
            applied.push(param + "=" + val);
            break;
          }
        } catch(pe) {
          // tentativa seguinte
        }
      }
    }

    // Color Wheels — acesso via índice de propriedade (mais estável)
    // Lumetri Color Wheels estão em subcomponente "Creative" ou "Color Wheels"
    var wheels = params.colorWheels;
    applyColorWheels(lumetri, wheels);

    return {
      clip: clipName,
      ok: true,
      applied: applied,
      strategy: "lumetri_direct"
    };

  } catch(e) {
    return { clip: "unknown", ok: false, error: e.message };
  }
}

/**
 * Aplica color wheels (sombras, meios-tons, altas luzes)
 */
function applyColorWheels(lumetri, wheels) {
  try {
    var props = lumetri.properties;

    // Nomes de color wheels em Lumetri (seção "Color Wheels & Match")
    var wheelDefs = [
      { key: "shadows",    names: ["Shadow Color",    "ShadowColor",    "Cor de sombra"]    },
      { key: "midtones",   names: ["Midtone Color",   "MidtoneColor",   "Cor de meio-tom"]  },
      { key: "highlights", names: ["Highlight Color", "HighlightColor", "Cor de realce"]    }
    ];

    for (var w = 0; w < wheelDefs.length; w++) {
      var def = wheelDefs[w];
      var wheelData = wheels[def.key];
      if (!wheelData) continue;

      for (var n = 0; n < def.names.length; n++) {
        try {
          var prop = props.getNamedProperty(def.names[n]);
          if (prop && prop.numProperties >= 3) {
            // Color wheel: {r, g, b} + wheel position
            prop.properties[0].setValue(wheelData.r, true); // Red
            prop.properties[1].setValue(wheelData.g, true); // Green
            prop.properties[2].setValue(wheelData.b, true); // Blue
            break;
          }
        } catch(ce) {
          // continua
        }
      }
    }
  } catch(e) {
    log("applyColorWheels erro: " + e.message);
  }
}

/**
 * Tenta criar adjustment layer via API Premiere (Premiere 2022+)
 */
function tryCreateAdjustmentLayer(seq, trackIdx, startSec, endSec, params) {
  try {
    // Premiere 2022+ oferece seq.createAdjustmentLayer() em algumas versões
    // Verificar disponibilidade
    if (typeof seq.createAdjustmentLayer === "function") {
      var startTicks = startSec * 254016000000;
      var endTicks   = endSec   * 254016000000;

      var adjItem = seq.createAdjustmentLayer();
      if (!adjItem) return { ok: false, error: "createAdjustmentLayer retornou null" };

      // Posicionar na faixa correta
      var adjTrack = seq.videoTracks[trackIdx];
      adjTrack.insertClip(adjItem, startSec);

      // Aplicar Lumetri ao adjustment layer
      var placed = adjTrack.clips[adjTrack.clips.numItems - 1];
      if (placed) {
        applyLumetriToClip(placed, params, 0);
        return { ok: true, name: placed.name };
      }
    }
    return { ok: false, reason: "createAdjustmentLayer não disponível nesta versão" };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}

/**
 * Reseta correções Lumetri nos clips selecionados
 */
function resetColorGrade() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return safeJSON({ error: "Sem sequência ativa" });

    var count = 0;
    var tracks = seq.videoTracks;

    for (var ti = 0; ti < tracks.numTracks; ti++) {
      var track = tracks[ti];
      for (var ci = 0; ci < track.clips.numItems; ci++) {
        var clip = track.clips[ci];
        if (!clip.isSelected()) continue;

        var components = clip.components;
        for (var i = 0; i < components.numItems; i++) {
          if (components[i].displayName.indexOf("Lumetri") >= 0) {
            components[i].remove(false, true); // remove sem ripple, com undo
            count++;
            break;
          }
        }
      }
    }

    return safeJSON({ ok: true, removed: count });
  } catch(e) {
    return safeJSON({ error: e.message });
  }
}

/**
 * Retorna versão e status do plugin
 */
function getPluginInfo() {
  return safeJSON({
    name: "ClipPaste AI",
    version: "1.0.0",
    author: "Alex Ascencio",
    premiereVersion: app.version,
    platform: $.os
  });
}
