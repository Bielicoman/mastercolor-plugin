/**
 * panel.js — Controller do Painel ClipPaste AI
 * by Alex Ascencio
 *
 * Orquestra: ColorEngine → UI → Lumetri Bridge
 */

'use strict';

/* ─── Estado ──────────────────────────────────────────────────────── */
const state = {
  params: null,
  profile: null,
  refDataUrl: null,
  analysisRunning: false
};

/* ─── CSInterface ────────────────────────────────────────────────── */
const cs = typeof CSInterface !== 'undefined' ? new CSInterface() : null;

function evalScript(fn, arg, cb) {
  if (!cs) { if (cb) cb('{"error":"Premiere não conectado"}'); return; }
  const call = arg !== undefined
    ? `${fn}(${JSON.stringify(JSON.stringify(arg))})`
    : `${fn}()`;
  cs.evalScript(call, cb || function(){});
}

/* ─── Init ───────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  loadJSX();
  setupDropZone();
  setupButtons();
  updateStatus();
});

function loadJSX() {
  if (!cs) { setStatus('preview', 'Dev mode — Premiere offline'); return; }
  const ext = cs.getSystemPath(SystemPath.EXTENSION);
  const path = ext + '/src/lumetri-bridge.jsx';
  cs.evalScript(`$.evalFile("${path.replace(/\\/g, '/')}")`, (result) => {
    evalScript('getPluginInfo', undefined, (info) => {
      try {
        const d = JSON.parse(info);
        if (d.premiereVersion) setStatus('live', 'Premiere Pro ' + d.premiereVersion);
        else setStatus('error', 'Conectar ao Premiere');
      } catch(e) {
        setStatus('error', 'Erro ao carregar');
      }
    });
  });
}

/* ─── Drop Zone ──────────────────────────────────────────────────── */
function setupDropZone() {
  const drop = document.getElementById('dropzone');
  const input = document.getElementById('fileInput');

  drop.addEventListener('click', () => input.click());
  input.addEventListener('change', e => {
    if (e.target.files[0]) processFile(e.target.files[0]);
  });

  drop.addEventListener('dragover', e => {
    e.preventDefault();
    drop.classList.add('dragover');
  });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', e => {
    e.preventDefault();
    drop.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) processFile(file);
    else showToast('Arquivo inválido. Use PNG, JPG ou WebP.', 'error');
  });
}

/* ─── Processar Referência ───────────────────────────────────────── */
async function processFile(file) {
  if (state.analysisRunning) return;
  state.analysisRunning = true;
  setStatus('processing', 'Analisando...');
  showSection('analyzing');

  try {
    const result = await ColorEngine.analyzeFile(file);
    state.params   = result.params;
    state.profile  = result.profile;
    state.refDataUrl = result.dataUrl;

    renderAnalysis(result);
    showSection('results');
    setStatus('live', 'Análise pronta');

  } catch(e) {
    showToast('Erro ao analisar imagem: ' + e.message, 'error');
    showSection('empty');
    setStatus('error', 'Erro na análise');
  } finally {
    state.analysisRunning = false;
  }
}

/* ─── Renderizar Análise ─────────────────────────────────────────── */
function renderAnalysis({ params, profile }) {
  const m = params.meta;

  // Thumbnail de referência
  const thumb = document.getElementById('refThumb');
  if (thumb && state.refDataUrl) thumb.src = state.refDataUrl;

  // Badges de look
  document.getElementById('lookBadge').textContent = m.dominant;
  document.getElementById('tempBadge').textContent = m.colorTemp + 'K';
  document.getElementById('dynBadge').textContent  = m.dynamicRange;
  document.getElementById('satBadge').textContent  = m.saturation + '%';

  // Parâmetros Lumetri
  const b = params.basic;
  setParam('exposure',    b.exposure,    -3.5, 3.5,   1);
  setParam('contrast',    b.contrast,    -60,  60,    0);
  setParam('highlights',  b.highlights,  -90,  30,    0);
  setParam('shadows',     b.shadows,     -60,  80,    0);
  setParam('whites',      b.whites,      -60,  40,    0);
  setParam('blacks',      b.blacks,      -60,  50,    0);
  setParam('temperature', b.temperature, -55,  55,    1);
  setParam('tint',        b.tint,        -35,  35,    1);
  setParam('saturation',  b.saturation,  60,   155,   1);
  setParam('vibrance',    b.vibrance,    -40,  50,    1);

  // Color wheels
  renderWheels(params.colorWheels);

  // Warning clips
  const clipWarn = document.getElementById('clipWarning');
  if (clipWarn) {
    clipWarn.style.display = m.overexposed > 2 ? 'flex' : 'none';
    if (m.overexposed > 2) {
      clipWarn.querySelector('span').textContent =
        `${m.overexposed}% de pixels super-expostos — proteção ativada`;
    }
  }
}

function setParam(id, value, min, max, decimals) {
  const row = document.getElementById('param-' + id);
  if (!row) return;

  const valEl  = row.querySelector('.param-value');
  const barEl  = row.querySelector('.param-bar-fill');
  const numEl  = row.querySelector('.param-number');

  if (valEl) valEl.textContent = value.toFixed(decimals);
  if (numEl) numEl.textContent = value.toFixed(decimals);

  // Posicionar barra (0 = centro para valores bi-direcionais)
  if (barEl) {
    const range = max - min;
    const pct = ((value - min) / range) * 100;
    barEl.style.width  = Math.abs(value) / Math.max(Math.abs(min), Math.abs(max)) * 50 + '%';
    barEl.style.left   = value >= 0 ? '50%' : (50 - Math.abs(value) / Math.max(Math.abs(min), Math.abs(max)) * 50) + '%';
    barEl.classList.toggle('negative', value < 0);
  }
}

function renderWheels(wheels) {
  const keys = ['shadows', 'midtones', 'highlights'];
  keys.forEach(key => {
    const canvas = document.getElementById('wheel-' + key);
    if (!canvas) return;
    drawColorWheel(canvas, wheels[key]);
  });
}

function drawColorWheel(canvas, data) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  const cx = w / 2, cy = h / 2, r = w / 2 - 2;

  ctx.clearRect(0, 0, w, h);

  // Círculo de fundo
  const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.1)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Cruz de referência
  ctx.strokeStyle = 'rgba(255,255,255,0.12)';
  ctx.lineWidth = 0.5;
  ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx, cy + r); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx - r, cy); ctx.lineTo(cx + r, cy); ctx.stroke();

  // Ponto de cor
  if (!data) return;
  const mag = Math.sqrt(data.r * data.r + data.g * data.g + data.b * data.b);
  if (mag < 0.001) {
    // Neutro: ponto no centro
    ctx.beginPath();
    ctx.arc(cx, cy, 3, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.fill();
    return;
  }

  // Converter r/g/b em ângulo e distância no wheel
  // r → 0°, g → 120°, b → 240°
  const angle = Math.atan2(data.g - data.b, data.r - data.b);
  const dist  = Math.min(mag * r * 2, r - 4);
  const px = cx + Math.cos(angle) * dist;
  const py = cy + Math.sin(angle) * dist;

  // Linha do centro ao ponto
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(px, py);
  ctx.strokeStyle = `rgba(${
    Math.round(128 + data.r * 255)},${
    Math.round(128 + data.g * 255)},${
    Math.round(128 + data.b * 255)},0.6)`;
  ctx.lineWidth = 1;
  ctx.stroke();

  // Ponto de cor
  ctx.beginPath();
  ctx.arc(px, py, 4, 0, Math.PI * 2);
  ctx.fillStyle = `rgb(${
    Math.round(Math.max(0, 128 + data.r * 512))},${
    Math.round(Math.max(0, 128 + data.g * 512))},${
    Math.round(Math.max(0, 128 + data.b * 512))})`;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.8)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

/* ─── Aplicar no Premiere ────────────────────────────────────────── */
function setupButtons() {
  const btnApply = document.getElementById('btnApply');
  const btnReset = document.getElementById('btnReset');
  const btnNew   = document.getElementById('btnNew');

  if (btnApply) btnApply.addEventListener('click', applyGrade);
  if (btnReset) btnReset.addEventListener('click', resetGrade);
  if (btnNew)   btnNew.addEventListener('click',   () => { showSection('empty'); state.params = null; });
}

function applyGrade() {
  if (!state.params) { showToast('Cole uma imagem de referência primeiro.', 'warn'); return; }

  const btn = document.getElementById('btnApply');
  btn.disabled = true;
  btn.textContent = 'Aplicando...';
  setStatus('processing', 'Aplicando no Premiere...');

  evalScript('getSelectedClipsInfo', undefined, (info) => {
    try {
      const d = JSON.parse(info);
      if (d.error) throw new Error(d.error);
      if (d.count === 0) {
        showToast('Selecione ao menos um clip na timeline.', 'warn');
        btn.disabled = false; btn.textContent = 'Aplicar Grade';
        setStatus('live', 'Nenhum clip selecionado');
        return;
      }

      evalScript('applyColorGrade', state.params, (result) => {
        btn.disabled = false; btn.textContent = 'Aplicar Grade';
        try {
          const r = JSON.parse(result);
          if (r.error) throw new Error(r.error);
          const n = r.clipsModified || 0;
          showToast(`✓ Grade aplicado em ${n} clip${n !== 1 ? 's' : ''}`, 'success');
          setStatus('live', `Grade aplicado — ${n} clip${n !== 1 ? 's' : ''}`);
        } catch(e) {
          showToast('Erro: ' + e.message, 'error');
          setStatus('error', 'Falha na aplicação');
        }
      });
    } catch(e) {
      btn.disabled = false; btn.textContent = 'Aplicar Grade';
      showToast(e.message, 'error');
      setStatus('error', e.message);
    }
  });
}

function resetGrade() {
  evalScript('resetColorGrade', undefined, (result) => {
    try {
      const r = JSON.parse(result);
      if (r.error) { showToast(r.error, 'error'); return; }
      showToast(`Lumetri removido de ${r.removed} clip${r.removed !== 1 ? 's' : ''}`, 'success');
    } catch(e) {
      showToast('Erro ao resetar', 'error');
    }
  });
}

/* ─── Helpers de UI ──────────────────────────────────────────────── */
function showSection(id) {
  ['empty', 'analyzing', 'results'].forEach(s => {
    const el = document.getElementById('section-' + s);
    if (el) el.style.display = s === id ? 'flex' : 'none';
  });
}

function setStatus(state, msg) {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  if (!dot || !text) return;

  dot.className = 'status-dot ' + state;
  text.textContent = msg;
}

function updateStatus() {
  setStatus('idle', 'Aguardando referência');
}

let toastTimer;
function showToast(msg, type) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.className = 'toast visible ' + (type || '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 3500);
}
